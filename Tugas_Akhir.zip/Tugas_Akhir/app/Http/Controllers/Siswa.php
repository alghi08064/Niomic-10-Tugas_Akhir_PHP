<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use App\tbl_biodata;

class Siswa extends Controller
{
  public function getData(){
    $data = DB::table('tbl_biodata')->get();
    if(count($data) > 0){
      $res['message'] = "Success!";
      $res['value'] = $data;
      return response($res);
    }else{
      $res['message'] = "Empty!";
      return response($res);
    }
  }

  public function store(Request $request){
    $this->validate($request, [
      'file_foto' => 'required|max:2048'
    ]);

    // menyimpan data file yang akan di upload ke variabel $file
    $file = $request->file('file_foto');
    $nama_file = time()."_".$file->getClientOriginalName();

    // isi dengan nama folder tempat dimana file akan di upload
    $tujuan_upload = 'data_file';
    if($file->move($tujuan_upload,$nama_file)){
      $data = tbl_biodata::create([
        'nama' => $request->nama,
        'no_hp' => $request->no_hp,
        'alamat' => $request->alamat,
        'hobi' => $request->hobi,
        'foto' => $nama_file
      ]);
      $res['message'] = "Success!";
      $res['value'] = $data;
      return response($res);
    }
  }

  public function update(Request $request) {
    if(!empty($request->file)){
      $this->validate($request, [
        'file_foto' => 'required|max:2048'
      ]);

      // menyimpan data file yang akan di upload ke variabel $file
      $file = $request->file('file_foto');
      $nama_file = time()."_".$file->getClientOriginalName();

      // isi dengan nama folder tempat dimana file akan di upload
      $tujuan_upload = 'data_file';
      $file->move($tujuan_upload,$nama_file);
      $data = DB::table('tbl_biodata')->where('id',$request->id)->get();
      foreach ($data as $siswa) {
        @unlink(public_path('data_file/'.$siswa->foto));
        $keterangan = DB::table('tbl_biodata')->where('id',$request->id)->update([
          'nama' => $request->nama,
          'no_hp' => $request->no_hp,
          'alamat' => $request->alamat,
          'hobi' => $request->hobi,
          'foto' => $nama_file
        ]);
        $res['message'] = "Success!";
        $res['value'] = $keterangan;
        return response($res);
      }
    }
    else{
      $data = DB::table('tbl_biodata')->where('id',$request->id)->get();
      foreach ($data as $siswa) {
        $keterangan = DB::table('tbl_biodata')->where('id',$request->id)->update([
          'nama' => $request->nama,
          'no_hp' => $request->no_hp,
          'alamat' => $request->alamat,
          'hobi' => $request->hobi,
        ]);
        $res['message'] = "Success!";
        $res['value'] = $keterangan;
        return response($res);
      }
    }
  }

  public function hapus($id){
    $data = DB::table('tbl_biodata')->where('id',$id)->get();
    foreach ($data as $siswa) {
      if (file_exists(public_path('data_file/'.$siswa->foto))) {
        @unlink(public_path('data_file/'.$siswa->foto));
        DB::table('tbl_biodata')->where('id',$id)->delete();
        $res['message'] = "Success!";
        return response($res);
      }
      else{
        $res['message'] = "Empty!";
        return response($res);
      }
    }

  }

  public function getDetail($id){
    $data = DB::table('tbl_biodata')->where('id',$id)->get();
    if(count($data) > 0){
      $res['message'] = "Success!";
      $res['value'] = $data;
      return response($res);
    }else{
      $res['message'] = "Empty!";
      return response($res);
    }
  }

}
